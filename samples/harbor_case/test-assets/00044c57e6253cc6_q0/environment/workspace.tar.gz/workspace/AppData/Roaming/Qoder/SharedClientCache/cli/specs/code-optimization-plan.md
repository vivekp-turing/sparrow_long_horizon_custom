# 代码优化实施计划

## Context

本次优化基于代码质量评估，主要解决以下问题：
- 硬编码常量散落各处，缺乏统一管理
- 高频路径使用 `log.info` 导致性能开销
- `AccessLogGlobalFilter.java` 文件过大（37KB/847行），职责过多

优化目标是提升代码可维护性、降低性能开销、遵循单一职责原则。

---

## Phase 1: 常量统一化

### 1.1 创建新常量类

遵循现有 `GatewayConfigConstants.java` 的 interface 模式，创建以下常量类：

| 常量类 | 路径 | 内容 |
|--------|------|------|
| `CacheConstants.java` | `constants/CacheConstants.java` | 缓存容量、过期时间等 |
| `ScheduleConstants.java` | `constants/ScheduleConstants.java` | 调度任务间隔时间 |
| `RateLimitConstants.java` | `constants/RateLimitConstants.java` | 限流键前缀、窗口配置 |
| `AuthConstants.java` | `constants/AuthConstants.java` | 认证时钟偏移、nonce过期、JWT缓存 |

### 1.2 替换硬编码引用

修改以下文件中的硬编码值：

**JwtValidationCache.java**
- `MAX_CACHE_SIZE = 10000` → `CacheConstants.JWT_CACHE_MAX_SIZE`
- `fixedRate = 60000` → `CacheConstants.JWT_CACHE_CLEANUP_INTERVAL_MS`
- `300_000` (默认过期) → `AuthConstants.DEFAULT_JWT_EXPIRY_MS`

**ShadowQuotaManager.java**
- `FALLBACK_THRESHOLD_MS = 3600000` → `ScheduleConstants.QUOTA_FALLBACK_THRESHOLD_MS`
- `RECOVERY_DURATION_MS = 10000` → `ScheduleConstants.QUOTA_RECOVERY_DURATION_MS`
- `fixedRate = 1000` → `ScheduleConstants.QUOTA_UPDATE_INTERVAL_MS`
- `"rate_limit:*:"` → `RateLimitConstants.RATE_LIMIT_KEY_SCAN_PATTERN`

**HybridRateLimiterFilter.java**
- `maximumSize(10000)` → `RateLimitConstants.RATE_LIMITER_CACHE_MAX_SIZE`
- `expireAfterWrite(1, TimeUnit.HOURS)` → 使用常量计算
- `"rate_limit:"` → `RateLimitConstants.RATE_LIMIT_KEY_PREFIX`

**HmacSignatureAuthProcessor.java**
- `DEFAULT_CLOCK_SKEW_MINUTES = 5` → `AuthConstants.DEFAULT_CLOCK_SKEW_MINUTES`
- `NONCE_EXPIRY_MS = 600000` → `AuthConstants.DEFAULT_NONCE_EXPIRY_MS`

### 1.3 GatewayResponseHelper改进

修改 `util/GatewayResponseHelper.java`，使用 ErrorCode 枚举替代硬编码：

| 行号 | 当前代码 | 改进后 |
|------|----------|--------|
| 111 | `40001` | `ErrorCode.BAD_REQUEST.getCode()` |
| 118 | `40101` | `ErrorCode.UNAUTHORIZED.getCode()` |
| 125 | `40301` | `ErrorCode.FORBIDDEN.getCode()` |
| 132 | `40401` | `ErrorCode.NOT_FOUND.getCode()` |
| 155 | `52901` | `ErrorCode.RATE_LIMIT_EXCEEDED.getCode()` |
| 176 | `55301` | `ErrorCode.CIRCUIT_BREAKER_OPEN.getCode()` |
| 200 | `50003` | `ErrorCode.SERIALIZATION_ERROR.getCode()` |

---

## Phase 2: 日志级别优化

### 2.1 需修改的文件

| 文件 | 行号 | 问题 | 修改方案 |
|------|------|------|----------|
| `MultiServiceLoadBalancerFilter.java` | 104 | `log.info` 每次 filter 调用 | 改为 `log.debug` |
| `MultiServiceLoadBalancerFilter.java` | 243 | `log.info` 每次路由 | 改为 `log.debug` |
| `SecurityGlobalFilter.java` | 103 | `log.info` 每次 filter 调用 | 改为 `log.debug` |
| `SecurityGlobalFilter.java` | 136 | `log.info` 每次 filter 调用 | 改为 `log.debug` |
| `InstanceFilter.java` | 124 | `log.info` 每次实例选择 | 改为 `log.debug` + 条件包装 |
| `TraceCaptureGlobalFilter.java` | 194 | `log.info` 每个请求完成 | 改为 `log.debug` + 条件包装 |

### 2.2 修改模式

```java
// 直接降级
log.info("...") → log.debug("...")

// 条件包装（用于可能包含大量数据的日志）
if (log.isDebugEnabled()) {
    log.debug("Multi-service routing: route={}, service={}, ...", ...);
}
```

---

## Phase 3: AccessLogGlobalFilter拆分

### 3.1 目标目录结构

```
filter/accesslog/
├── AccessLogGlobalFilter.java        (主Filter，~200行)
├── config/
│   ├── AccessLogConfig.java          (配置模型)
│   └── AccessLogConfigManager.java   (配置加载监听)
├── formatter/
│   ├── AccessLogEntryBuilder.java    (日志条目构建)
│   └── AccessLogJsonFormatter.java   (JSON格式化)
├── body/
│   ├── RequestBodyCacher.java        (请求体缓存)
│   └── ResponseBodyCacher.java       (响应体缓存)
├── detector/
│   └── BinaryContentDetector.java    (二进制检测，复用BinaryContentConstants)
├── extractor/
│   ├── ClientIpExtractor.java        (IP提取)
│   ├── AuthInfoExtractor.java        (认证信息提取)
│   └── ServiceInfoExtractor.java     (服务信息提取)
├── sanitizer/
│   └── SensitiveDataSanitizer.java   (敏感数据脱敏)
├── appender/
│   └── AccessLogAppenderManager.java (Logback Appender管理)
└── constants/
    └── AccessLogConstants.java       (专用常量)
```

### 3.2 拆分步骤

**Step 1**: 提取配置类
- 从行774-838提取 `AccessLogConfig` 内部类 → `config/AccessLogConfig.java`
- 提取配置加载逻辑 → `config/AccessLogConfigManager.java`

**Step 2**: 提取Appender管理
- 从行140-194提取 `updateLogbackAppenders()` → `appender/AccessLogAppenderManager.java`

**Step 3**: 提取Body缓存
- 从行267-317提取响应体包装 → `body/ResponseBodyCacher.java`
- 从行319-359提取请求体缓存 → `body/RequestBodyCacher.java`

**Step 4**: 提取检测器
- 从行608-767提取二进制检测方法 → `detector/BinaryContentDetector.java`

**Step 5**: 提取信息提取器
- 从行568-580提取IP提取 → `extractor/ClientIpExtractor.java`
- 从行474-512提取认证信息 → `extractor/AuthInfoExtractor.java`
- 从行449-472提取服务信息 → `extractor/ServiceInfoExtractor.java`

**Step 6**: 提取脱敏处理
- 从行514-550提取脱敏方法 → `sanitizer/SensitiveDataSanitizer.java`

**Step 7**: 重构主Filter
- 精简主Filter至~200行
- 通过 @Autowired 注入各模块

---

## Phase 4: 验证

### 4.1 运行测试

```bash
cd my-gateway && mvn test
cd gateway-admin && mvn test
```

### 4.2 验证清单

| 检查项 | 方法 |
|--------|------|
| 常量引用正确 | 运行单元测试，检查编译错误 |
| 错误码一致 | 发送错误请求，验证响应码 |
| 日志输出正确 | 设置不同日志级别，发送高频请求 |
| AccessLog功能完整 | 发送各类请求，检查日志输出 |

### 4.3 性能基准

- 启动网关后发送高频请求（如100 QPS）
- 观察 INFO 级别日志输出量是否减少
- 检查内存使用是否稳定

---

## 关键文件路径

```
# 常量类（新建）
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\CacheConstants.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\ScheduleConstants.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\RateLimitConstants.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\AuthConstants.java

# 常量类（参考）
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\GatewayConfigConstants.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\FilterOrderConstants.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\constants\BinaryContentConstants.java

# 需修改的文件
d:\source\my-gateway\src\main\java\com\leoli\gateway\auth\JwtValidationCache.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\limiter\ShadowQuotaManager.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\ratelimit\HybridRateLimiterFilter.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\auth\HmacSignatureAuthProcessor.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\util\GatewayResponseHelper.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\loadbalancer\MultiServiceLoadBalancerFilter.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\security\SecurityGlobalFilter.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\loadbalancer\InstanceFilter.java
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\TraceCaptureGlobalFilter.java

# 拆分主文件
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\AccessLogGlobalFilter.java

# AccessLog拆分新建目录
d:\source\my-gateway\src\main\java\com\leoli\gateway\filter\accesslog\

# 错误码枚举（已存在）
d:\source\my-gateway\src\main\java\com\leoli\gateway\exception\ErrorCode.java
```

---

## 不改项说明

| 项目 | 原因 |
|------|------|
| `@Autowired(required = false)` | 使用场景合理（Redis降级、无注册中心降级），保持现状 |
| 已配置化的参数（如 `@Value` 注入的值） | 保持运维可调整性，不提取为常量 |