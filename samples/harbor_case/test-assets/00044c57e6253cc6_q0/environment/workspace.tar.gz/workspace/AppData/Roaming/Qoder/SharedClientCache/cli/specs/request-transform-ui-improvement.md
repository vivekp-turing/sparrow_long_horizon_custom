# 请求转换策略 UI 改进计划

## Context

用户反馈请求转换策略（REQUEST_TRANSFORM）的创建界面不够友好，第一眼看不知道怎么填写。当前实现将 `object` 和 `array` 类型字段渲染为 TextArea，要求用户手动输入 JSON 格式，没有为固定可选值提供下拉选择。

**问题根源：**
1. 数据库 config_schema 定义过于简单，没有提供下拉选项信息
2. DynamicConfigFields 组件对 object/array 类型只渲染 TextArea
3. 没有类似 AUTH/MULTI_DIM_RATE_LIMITER 的专用表单组件

**改进目标：**
- 协议转换配置：sourceFormat (JSON/XML/FORM)、targetFormat (JSON/XML) 改为下拉选择
- 字段映射配置：使用 Form.List 动态添加映射规则，transform (COPY/RENAME/REMOVE/DEFAULT) 下拉选择
- 数据脱敏配置：使用 Form.List 动态添加脱敏规则，maskType (FULL/PARTIAL/CUSTOM)、keepPosition (START/END) 下拉选择

---

## Implementation Plan

### Phase 1: 后端 - 更新数据库 Schema

**文件:** `gateway-admin/src/main/resources/db/migration/V14__request_transform_schema.sql`

创建新的迁移脚本，更新 REQUEST_TRANSFORM 和 RESPONSE_TRANSFORM 的 config_schema：

```sql
-- REQUEST_TRANSFORM config_schema
UPDATE strategy_types SET config_schema = '{
  "fields": [
    {"name": "maxBodySize", "type": "number", "label": "最大Body大小", "default": 1048576, "min": 1, "max": 104857600, "unit": "bytes"},
    {"name": "validateAfterTransform", "type": "switch", "label": "转换后验证JSON", "default": false}
  ],
  "hasSubSchemas": true,
  "transformSections": ["protocolTransform", "fieldMapping", "dataMasking"]
}' WHERE type_code = 'REQUEST_TRANSFORM';

-- RESPONSE_TRANSFORM config_schema (类似结构)
UPDATE strategy_types SET config_schema = '...' WHERE type_code = 'RESPONSE_TRANSFORM';
```

### Phase 2: 后端 - 动态注入 subSchemas

**文件:** `gateway-admin/src/main/java/com/leoli/gateway/admin/service/StrategyTypeService.java`

添加 REQUEST_TRANSFORM 和 RESPONSE_TRANSFORM 的 subSchemas：

```java
// REQUEST_TRANSFORM subSchemas
private static final Map<String, Object> REQUEST_TRANSFORM_SUB_SCHEMAS = new HashMap<>();

static {
    // protocolTransform section
    Map<String, Object> protocolSchema = new HashMap<>();
    protocolSchema.put("sectionLabel", "协议转换配置");
    protocolSchema.put("fields", List.of(
        createSwitchField("enabled", "启用协议转换", false),
        createSelectField("sourceFormat", "源格式", "JSON",
            List.of("JSON", "XML", "FORM").stream().map(f -> {
                Map<String, Object> opt = new HashMap<>();
                opt.put("value", f);
                opt.put("label", f.equals("JSON") ? "JSON" : f.equals("XML") ? "XML" : "表单(FORM)");
                return opt;
            }).toList()),
        createSelectField("targetFormat", "目标格式", "JSON",
            List.of("JSON", "XML").stream().map(f -> {...}).toList()),
        createSwitchField("preserveOriginalContentType", "保留原Content-Type", false),
        createField("customContentType", "text", "自定义Content-Type", null)
    ));
    REQUEST_TRANSFORM_SUB_SCHEMAS.put("protocolTransform", protocolSchema);

    // fieldMapping section (multiRule pattern)
    Map<String, Object> fieldMappingSchema = new HashMap<>();
    fieldMappingSchema.put("sectionLabel", "字段映射配置");
    fieldMappingSchema.put("multiRule", true);
    fieldMappingSchema.put("ruleLabel", "映射规则");
    fieldMappingSchema.put("ruleFields", List.of(
        createField("sourcePath", "text", "源字段路径(JSONPath)", null, "$.user.name"),
        createField("targetPath", "text", "目标字段路径", null, "$.userData.fullName"),
        createSelectField("transform", "转换类型", "COPY",
            List.of("COPY", "RENAME", "REMOVE", "DEFAULT").stream().map(t -> {
                Map<String, Object> opt = new HashMap<>();
                opt.put("value", t);
                opt.put("label", t.equals("COPY") ? "复制" : t.equals("RENAME") ? "重命名" : t.equals("REMOVE") ? "删除" : "默认值");
                return opt;
            }).toList()),
        createField("defaultValue", "text", "默认值", null, "当源字段不存在时使用"),
        createField("valueTransform", "text", "值转换表达式", null, "${value.toUpperCase()}")
    ));
    REQUEST_TRANSFORM_SUB_SCHEMAS.put("fieldMapping", fieldMappingSchema);

    // dataMasking section (multiRule pattern)
    Map<String, Object> dataMaskingSchema = new HashMap<>();
    dataMaskingSchema.put("sectionLabel", "数据脱敏配置");
    dataMaskingSchema.put("multiRule", true);
    dataMaskingSchema.put("ruleLabel", "脱敏规则");
    dataMaskingSchema.put("ruleFields", List.of(
        createField("fieldPath", "text", "字段路径(JSONPath)", null, "$.password"),
        createSelectField("maskType", "脱敏类型", "FULL",
            List.of("FULL", "PARTIAL", "CUSTOM").stream().map(m -> {
                Map<String, Object> opt = new HashMap<>();
                opt.put("value", m);
                opt.put("label", m.equals("FULL") ? "完全脱敏" : m.equals("PARTIAL") ? "部分脱敏" : "自定义正则");
                return opt;
            }).toList()),
        createField("pattern", "text", "正则表达式", null, "CUSTOM类型时使用"),
        createField("replacement", "text", "替换字符串", "***", null),
        createNumberField("keepLength", "保留字符数", 0, 0, 100, null),
        createSelectField("keepPosition", "保留位置", "START",
            List.of("START", "END").stream().map(p -> {
                Map<String, Object> opt = new HashMap<>();
                opt.put("value", p);
                opt.put("label", p.equals("START") ? "开头" : "结尾");
                return opt;
            }).toList())
    ));
    REQUEST_TRANSFORM_SUB_SCHEMAS.put("dataMasking", dataMaskingSchema);
}
```

更新 `getFullConfigSchema` 方法注入 subSchemas：

```java
if ("REQUEST_TRANSFORM".equals(typeCode) && Boolean.TRUE.equals(schema.get("hasSubSchemas"))) {
    schema.put("subSchemas", REQUEST_TRANSFORM_SUB_SCHEMAS);
    schema.remove("hasSubSchemas");
}
```

### Phase 3: 前端 - 创建 RequestTransformFields 组件

**文件:** `gateway-ui/src/components/DynamicConfigFields.tsx`

新增专用组件处理请求转换的多区块配置：

```tsx
/**
 * Request Transform fields with multiple configuration sections.
 * Each section (protocolTransform, fieldMapping, dataMasking) has its own card.
 */
export function RequestTransformFields({ schema, form, t }: DynamicConfigFieldsProps) {
  const subSchemas = schema?.subSchemas || {};
  const sections = ['protocolTransform', 'fieldMapping', 'dataMasking'];

  return (
    <>
      {/* Base fields */}
      {schema?.fields && (
        <Row gutter={16}>
          {schema.fields.map((field) => renderField(field, form, t))}
        </Row>
      )}

      {/* Protocol Transform Section */}
      {subSchemas.protocolTransform && (
        <Card title={subSchemas.protocolTransform.sectionLabel || '协议转换'} style={{ marginBottom: 16 }}>
          <Form.Item name="protocolTransform" noStyle>
            {subSchemas.protocolTransform.fields.map((field) => renderField(field, form, t))}
          </Form.Item>
        </Card>
      )}

      {/* Field Mapping Section - dynamic rules */}
      {subSchemas.fieldMapping?.multiRule && (
        <Card title={subSchemas.fieldMapping.sectionLabel || '字段映射'} style={{ marginBottom: 16 }}>
          <Form.List name="fieldMappingRules">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Card key={key} size="small" style={{ marginBottom: 8 }}
                    title={`${subSchemas.fieldMapping.ruleLabel || '规则'} ${name + 1}`}
                    extra={<Button danger icon={<DeleteOutlined />} onClick={() => remove(name)} />}>
                    <Row gutter={16}>
                      {subSchemas.fieldMapping.ruleFields.map((field) =>
                        renderRuleField(field, name, restField, t)
                      )}
                    </Row>
                  </Card>
                ))}
                <Button type="dashed" block icon={<PlusOutlined />} onClick={() => add({ transform: 'COPY' })}>
                  添加映射规则
                </Button>
              </>
            )}
          </Form.List>
        </Card>
      )}

      {/* Data Masking Section - dynamic rules */}
      {subSchemas.dataMasking?.multiRule && (
        <Card title={subSchemas.dataMasking.sectionLabel || '数据脱敏'} style={{ marginBottom: 16 }}>
          <Form.List name="dataMaskingRules">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, ...restField }) => (
                  <Card key={key} size="small" style={{ marginBottom: 8 }}
                    title={`${subSchemas.dataMasking.ruleLabel || '规则'} ${name + 1}`}
                    extra={<Button danger icon={<DeleteOutlined />} onClick={() => remove(name)} />}>
                    <Form.Item noStyle shouldUpdate>
                      {({ getFieldValue }) => {
                        const maskType = getFieldValue(['dataMaskingRules', name, 'maskType']);
                        return (
                          <Row gutter={16}>
                            {subSchemas.dataMasking.ruleFields.map((field) => {
                              // 隐藏 PARTIAL 专属字段当 maskType 不是 PARTIAL
                              if ((field.name === 'keepLength' || field.name === 'keepPosition')
                                  && maskType !== 'PARTIAL') {
                                return null;
                              }
                              // 隐藏 pattern 字段当 maskType 不是 CUSTOM
                              if (field.name === 'pattern' && maskType !== 'CUSTOM') {
                                return null;
                              }
                              return renderRuleField(field, name, restField, t);
                            })}
                          </Row>
                        );
                      }}
                    </Form.Item>
                  </Card>
                ))}
                <Button type="dashed" block icon={<PlusOutlined />} onClick={() => add({ maskType: 'FULL', replacement: '***' })}>
                  添加脱敏规则
                </Button>
              </>
            )}
          </Form.List>
        </Card>
      )}
    </>
  );
}
```

### Phase 4: 前端 - 在 StrategiesPage 中集成

**文件:** `gateway-ui/src/pages/StrategiesPage.tsx`

在 `renderConfigFields` 函数中添加特殊处理：

```tsx
// Special handling for REQUEST_TRANSFORM with multiple sections
if (strategyType === 'REQUEST_TRANSFORM' && schema.subSchemas) {
  return <RequestTransformFields schema={schema} form={form} t={t} />;
}

// Special handling for RESPONSE_TRANSFORM (similar structure)
if (strategyType === 'RESPONSE_TRANSFORM' && schema.subSchemas) {
  return <ResponseTransformFields schema={schema} form={form} t={t} />;
}
```

### Phase 5: 前端 - 数据转换逻辑

**文件:** `gateway-ui/src/pages/StrategiesPage.tsx`

#### buildConfig 函数更新

将表单数据转换为后端需要的 config 结构：

```tsx
case 'REQUEST_TRANSFORM':
  return {
    enabled: true,
    maxBodySize: parseInt(values.maxBodySize) || 1048576,
    validateAfterTransform: values.validateAfterTransform || false,
    // 协议转换
    protocolTransform: values.protocolTransform || { enabled: false, sourceFormat: 'JSON', targetFormat: 'JSON' },
    // 字段映射
    fieldMapping: {
      enabled: (values.fieldMappingRules?.length || 0) > 0,
      mappings: values.fieldMappingRules || [],
      removeFields: values.removeFields ? values.removeFields.split(',').map(s => s.trim()) : [],
      addFields: values.addFields ? JSON.parse(values.addFields) : {}
    },
    // 数据脱敏
    dataMasking: {
      enabled: (values.dataMaskingRules?.length || 0) > 0,
      rules: values.dataMaskingRules || []
    }
  };
```

#### openEditModal 函数更新

将后端 config 转换为表单数据：

```tsx
// REQUEST_TRANSFORM 反向转换
if (strategy.strategyType === 'REQUEST_TRANSFORM') {
  const config = strategy.config || {};
  formValues.maxBodySize = config.maxBodySize || 1048576;
  formValues.validateAfterTransform = config.validateAfterTransform || false;
  formValues.protocolTransform = config.protocolTransform || {};
  formValues.fieldMappingRules = config.fieldMapping?.mappings || [];
  formValues.dataMaskingRules = config.dataMasking?.rules || [];
}
```

---

## Files to Modify

| 文件 | 改动类型 |
|------|----------|
| `gateway-admin/src/main/resources/db/migration/V14__request_transform_schema.sql` | 新建 |
| `gateway-admin/src/main/java/com/leoli/gateway/admin/service/StrategyTypeService.java` | 修改 |
| `gateway-ui/src/components/DynamicConfigFields.tsx` | 修改 |
| `gateway-ui/src/pages/StrategiesPage.tsx` | 修改 |

---

## Verification

1. **后端验证：**
   - 启动 gateway-admin 服务
   - 通过 API `/api/strategy-types/REQUEST_TRANSFORM` 获取完整 schema
   - 确认 subSchemas 包含 protocolTransform, fieldMapping, dataMasking

2. **前端验证：**
   - 启动 gateway-ui
   - 进入策略管理页面，点击创建策略
   - 选择"请求转换"策略类型
   - 确认：
     - 协议转换配置有下拉选择（sourceFormat, targetFormat）
     - 字段映射有动态添加规则按钮，transform 有下拉选择
     - 数据脱敏有动态添加规则按钮，maskType 有下拉选择
     - PARTIAL/CUSTOM 类型切换时显示/隐藏相关字段

3. **端到端测试：**
   - 创建一个请求转换策略，配置所有三种转换
   - 保存后刷新页面，编辑该策略，确认数据正确回显
   - 查看策略卡片，确认配置摘要正确显示