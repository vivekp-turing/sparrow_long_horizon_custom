2425→      'trace.filter_failure': '失败数',
2426→      'trace.filter_slowest': '最慢过滤器',
2427→      'trace.filter_warning': '部分过滤器执行失败',
2428→      // Distributed Tracing (Jaeger) - Chinese
2429→      'trace.distributed_traces': '分布式追踪',
2430→      'trace.distributed_detail': '分布式追踪详情',
2431→      'trace.jaeger_unavailable': 'Jaeger服务不可用',
2432→      'trace.jaeger_unavailable_desc': '请检查Jaeger是否正常运行，分布式追踪数据无法展示。',
2433→      'trace.select_service': '选择服务',
2434→      'trace.select_operation': '选择操作',
2435→      'trace.spans': 'Span数',
2436→      'trace.duration': '耗时',
2437→      'trace.services': '服务',
2438→      'trace.view_details': '详情',
2439→      'trace.span_timeline': 'Span时间线',
2440→      'trace.span_list': 'Span列表',
2441→      'trace.span_id': 'Span ID',
2442→      'trace.operation': '操作',
2443→      'trace.view_distributed': '查看分布式追踪',
2444→
2445→      // Request Replay Page
2446→      'replay.title': '请求回放调试器',
2447→      'replay.load_error': '加载追踪记录失败',
2448→      'replay.prepare_error': '准备回放失败',
2449→      'replay.execute_error': '执行回放失败',
2450→      'replay.trace_time': '时间',
2451→      'replay.method': '方法',
2452→      'replay.path': '路径',
2453→      'replay.status': '状态',
2454→      'replay.latency': '耗时',
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>