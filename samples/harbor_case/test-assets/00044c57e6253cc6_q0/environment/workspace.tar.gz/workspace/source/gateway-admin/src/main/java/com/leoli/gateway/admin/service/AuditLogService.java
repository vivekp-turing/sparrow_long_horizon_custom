102→
103→    /**
104→     * Build JPA Specification from query parameters.
105→     */
106→    private Specification<AuditLogEntity> buildSpecification(AuditLogQuery query) {
107→        return (root, cq, cb) -> {
108→            List<Predicate> predicates = new ArrayList<>();
109→
110→            // Instance ID filter
111→            if (query.getInstanceId() != null && !query.getInstanceId().isEmpty()) {
112→                predicates.add(cb.equal(root.get("instanceId"), query.getInstanceId()));
113→            }
114→
115→            // Target type filter
116→            if (query.getTargetType() != null && !query.getTargetType().isEmpty()) {
117→                predicates.add(cb.equal(root.get("targetType"), query.getTargetType()));
118→            }
119→
120→            // Target ID filter
121→            if (query.getTargetId() != null && !query.getTargetId().isEmpty()) {
122→                predicates.add(cb.equal(root.get("targetId"), query.getTargetId()));
123→            }
124→
125→            // Operation type filter
126→            if (query.getOperationType() != null && !query.getOperationType().isEmpty()) {
127→                predicates.add(cb.equal(root.get("operationType"), query.getOperationType()));
128→            }
129→
130→            // Operator filter
131→            if (query.getOperator() != null && !query.getOperator().isEmpty()) {
132→                predicates.add(cb.equal(root.get("operator"), query.getOperator()));
133→            }
134→
135→            // Operator type filter
136→            if (query.getOperatorType() != null && !query.getOperatorType().isEmpty()) {
137→                predicates.add(cb.equal(root.get("operatorType"), query.getOperatorType()));
138→            }
139→
140→            // Target name fuzzy search
141→            if (query.getTargetName() != null && !query.getTargetName().isEmpty()) {
142→                predicates.add(cb.like(cb.lower(root.get("targetName")), "%" + query.getTargetName().toLowerCase() + "%"));
143→            }
144→
145→            // Time range filter
146→            if (query.getStartTime() != null && query.getEndTime() != null) {
147→                predicates.add(cb.between(root.get("createdAt"), query.getStartTime(), query.getEndTime()));
148→            } else if (query.getStartTime() != null) {
149→                predicates.add(cb.greaterThanOrEqualTo(root.get("createdAt"), query.getStartTime()));
150→            } else if (query.getEndTime() != null) {
151→                predicates.add(cb.lessThanOrEqualTo(root.get("createdAt"), query.getEndTime()));
152→            }
153→
154→            return cb.and(predicates.toArray(new Predicate[0]));
155→        };
156→    }
157→
158→    /**
159→     * Get audit log statistics (aggregated counts).
160→     * Uses database queries instead of fetching all records.
161→     */
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>