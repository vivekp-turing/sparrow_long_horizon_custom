240→        }
241→
242→        // Step 6: Transform URI based on service type
243→        transformUriForServiceType(exchange, targetServiceId, serviceType);
244→
245→        log.info("Multi-service routing: route={}, service={}, version={}, type={}, weight={}",
246→                routeId, targetServiceId, targetVersion, serviceType, selectedBinding.getWeight());
247→
248→        return chain.filter(exchange);
249→    }
250→
251→    /**
252→     * Transform URI for multi-service mode.
253→     * Only called when selected service differs from route URI.
254→     * <p>
255→     * - STATIC:  static://serviceId + ORIGINAL_STATIC_URI_ATTR → DiscoveryLoadBalancerFilter handles
256→     * - DISCOVERY: lb://serviceId (no mark) → SCG native ReactiveLoadBalancer handles
257→     */
258→    private void transformUriForServiceType(ServerWebExchange exchange, String serviceId, ServiceBindingType type) {
259→        // Build new URI with appropriate scheme (path/query handled by downstream filters)
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>