308→
309→    /**
310→     * Get configuration change timeline for an instance.
311→     */
312→    @GetMapping("/timeline/{instanceId}")
313→    public ResponseEntity<Map<String, Object>> getTimeline(
314→            @PathVariable String instanceId,
315→            @RequestParam(defaultValue = "7") int days,
316→            @RequestParam(required = false) String targetType,
317→            @RequestParam(defaultValue = "100") int limit) {
318→
319→        try {
320→            AuditLogService.TimelineResult timeline = auditLogService.getTimeline(instanceId, days, targetType, limit);
321→            return ResponseEntity.ok(timeline.toMap());
322→        } catch (Exception e) {
323→            log.error("Failed to get timeline for instance {}", instanceId, e);
324→            return ResponseEntity.internalServerError().body(Map.of("error", e.getMessage()));
325→        }
326→    }
327→}
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>