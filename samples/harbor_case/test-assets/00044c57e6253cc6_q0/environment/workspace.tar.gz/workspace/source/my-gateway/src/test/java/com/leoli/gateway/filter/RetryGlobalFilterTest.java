100→
101→            verify(chain).filter(any());
102→        }
103→
104→        @Test
105→        @DisplayName("Filter should pass through when enabled is false in config")
106→        void testFilter_disabledInConfig() {
107→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
108→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
109→            when(strategyManager.getRetryConfig(anyString())).thenReturn(createDisabledConfig());
110→            when(chain.filter(any())).thenReturn(Mono.empty());
111→
112→            StepVerifier.create(filter.filter(exchange, chain))
113→                    .expectComplete()
114→                    .verify();
115→
116→            verify(chain).filter(any());
117→        }
118→    }
119→
120→    @Nested
121→    @DisplayName("Configuration Tests")
122→    class ConfigurationTests {
123→
124→        @Test
125→        @DisplayName("Should use default values when config is empty")
126→        void testConfig_defaultValues() {
127→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
128→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
129→            when(strategyManager.getRetryConfig(anyString())).thenReturn(new HashMap<>());
130→            when(chain.filter(any())).thenReturn(Mono.empty());
131→
132→            StepVerifier.create(filter.filter(exchange, chain))
133→                    .expectComplete()
134→                    .verify();
135→
136→            // Config should use defaults from RetryProperties (called in constructor and config parsing)
137→            verify(retryProperties, atLeast(1)).getDefaultMaxAttempts();
138→            verify(retryProperties, atLeast(1)).getDefaultRetryIntervalMs();
139→        }
140→
141→        @Test
142→        @DisplayName("Should use custom maxAttempts from config")
143→        void testConfig_customMaxAttempts() {
144→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
145→            Map<String, Object> config = createConfigWithMaxAttempts(5);
146→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
147→            when(strategyManager.getRetryConfig(anyString())).thenReturn(config);
148→            when(chain.filter(any())).thenReturn(Mono.empty());
149→
150→            StepVerifier.create(filter.filter(exchange, chain))
151→                    .expectComplete()
152→                    .verify();
153→
154→            verify(chain).filter(any());
155→        }
156→
157→        @Test
158→        @DisplayName("Should use custom retryIntervalMs from config")
159→        void testConfig_customRetryInterval() {
160→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
161→            Map<String, Object> config = createConfigWithRetryInterval(500);
162→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
163→            when(strategyManager.getRetryConfig(anyString())).thenReturn(config);
164→            when(chain.filter(any())).thenReturn(Mono.empty());
165→
166→            StepVerifier.create(filter.filter(exchange, chain))
167→                    .expectComplete()
168→                    .verify();
169→        }
170→    }
171→
172→    @Nested
173→    @DisplayName("Retry Execution Tests")
174→    class ExecutionTests {
175→
176→        @Test
177→        @DisplayName("Should retry on ConnectException")
178→        void testRetry_connectException() {
179→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
180→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
181→            when(strategyManager.getRetryConfig(anyString())).thenReturn(createEnabledConfig());
182→
183→            // First call fails with ConnectException, second succeeds
184→            when(chain.filter(any()))
185→                    .thenReturn(Mono.error(new java.net.ConnectException("Connection refused")))
186→                    .thenReturn(Mono.empty());
187→
188→            StepVerifier.create(filter.filter(exchange, chain))
189→                    .expectComplete()
190→                    .verify();
191→
192→            // Should have called chain.filter twice (first attempt + 1 retry)
193→            verify(chain, times(2)).filter(any());
194→        }
195→
196→        @Test
197→        @DisplayName("Should retry on 5xx status code")
198→        void testRetry_5xxStatusCode() {
199→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
200→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
201→            when(strategyManager.getRetryConfig(anyString())).thenReturn(createEnabledConfig());
202→
203→            // First call fails with 503, second succeeds
204→            when(chain.filter(any()))
205→                    .thenReturn(Mono.error(new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Service Unavailable")))
206→                    .thenReturn(Mono.empty());
207→
208→            StepVerifier.create(filter.filter(exchange, chain))
209→                    .expectComplete()
210→                    .verify();
211→
212→            verify(chain, times(2)).filter(any());
213→        }
214→
215→        @Test
216→        @DisplayName("Should retry on NotFoundException")
217→        void testRetry_notFoundException() {
218→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
219→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
220→            when(strategyManager.getRetryConfig(anyString())).thenReturn(createEnabledConfig());
221→
222→            // First call fails with NotFoundException, second succeeds
223→            when(chain.filter(any()))
224→                    .thenReturn(Mono.error(new NotFoundException("No instances available")))
225→                    .thenReturn(Mono.empty());
226→
227→            StepVerifier.create(filter.filter(exchange, chain))
228→                    .expectComplete()
229→                    .verify();
230→
231→            verify(chain, times(2)).filter(any());
232→        }
233→
234→        @Test
235→        @DisplayName("Should not retry on 4xx status code")
236→        void testNoRetry_4xxStatusCode() {
237→            MockServerWebExchange exchange = createMockExchange("/api/test", "test-route");
238→            when(strategyManager.isStrategyEnabled(anyString(), eq(StrategyDefinition.TYPE_RETRY))).thenReturn(true);
239→            when(strategyManager.getRetryConfig(anyString())).thenReturn(createEnabledConfig());
240→
241→            // 400 should not trigger retry
242→            when(chain.filter(any()))
243→                    .thenReturn(Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "Bad Request")));
244→
245→            StepVerifier.create(filter.filter(exchange, chain))
246→                    .expectError(ResponseStatusException.class)
247→                    .verify();
248→
249→            // Should only call chain.filter once (no retry)
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>