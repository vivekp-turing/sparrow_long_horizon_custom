 50→} from "@ant-design/icons";
 51→import { useParams, useNavigate, useLocation } from "react-router-dom";
 52→import { useTranslation } from "react-i18next";
 53→import axios from "axios";
 54→import LanguageSwitcher from "../components/LanguageSwitcher";
 55→
 56→// Lazy load sub-pages for better performance
 57→const ServicesPage = lazy(() => import("./ServicesPage"));
 58→const RoutesPage = lazy(() => import("./RoutesPage"));
 59→const StrategiesPage = lazy(() => import("./StrategiesPage"));
 60→const AuthPoliciesPage = lazy(() => import("./AuthPoliciesPage"));
 61→const CertificatePage = lazy(() => import("./CertificatePage"));
 62→const TracePage = lazy(() => import("./TracePage"));
 63→const MonitorPage = lazy(() => import("./MonitorPage"));
 64→const AlertPage = lazy(() => import("./AlertPage"));
 65→const AccessLogConfigPage = lazy(() => import("./AccessLogConfigPage"));
 66→const AuditLogsPage = lazy(() => import("./AuditLogsPage"));
 67→const DiagnosticPage = lazy(() => import("./DiagnosticPage"));
 68→const TrafficTopologyPage = lazy(() => import("./TrafficTopologyPage"));
 69→const FilterChainPage = lazy(() => import("./FilterChainPage"));
 70→const RequestReplayPage = lazy(() => import("./RequestReplayPage"));
 71→const AiCopilotPage = lazy(() => import("./AiCopilotPage"));
 72→const StressTestPage = lazy(() => import("./StressTestPage"));
 73→
 74→// Tab loading fallback component
 75→const TabLoading: React.FC = () => (
 76→  <div style={{
 77→    display: 'flex',
 78→    justifyContent: 'center',
 79→    alignItems: 'center',
 80→    minHeight: '300px',
 81→  }}>
 82→    <Spin size="large" />
 83→  </div>
 84→);
 85→
 86→import "./InstanceDetailPage.css";
 87→
 88→const { Title, Text } = Typography;
 89→
 90→interface GatewayInstance {
 91→  id: number;
 92→  instanceId: string;
 93→  instanceName: string;
 94→  clusterId: number;
 95→  clusterName: string;
 96→  namespace: string;
 97→  nacosNamespace: string;
 98→  nacosServerAddr?: string;
 99→  specType: string;
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>