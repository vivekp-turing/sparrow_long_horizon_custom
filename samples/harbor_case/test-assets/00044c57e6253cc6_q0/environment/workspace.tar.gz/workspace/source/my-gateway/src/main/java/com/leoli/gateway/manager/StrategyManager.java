253→    public Map<String, Object> getConfig(String routeId, String strategyType) {
254→        StrategyDefinition strategy = getStrategyForRoute(routeId, strategyType);
255→        if (Objects.isNull(strategy)) {
256→            // Try fallback to snapshot if config center is unhealthy
257→            if (!configCenterHealthy) {
258→                strategy = getStrategyFromSnapshot(routeId, strategyType);
259→                if (strategy != null) {
260→                    log.warn("Using snapshot fallback for strategy type: {}, routeId: {}", strategyType, routeId);
261→                }
262→            }
263→            if (Objects.isNull(strategy)) return null;
264→        }
265→        // Include strategyId in config for rate limiter key management
266→        Map<String, Object> configWithId = new HashMap<>(strategy.getConfig());
267→        configWithId.put("strategyId", strategy.getStrategyId());
268→        return configWithId;
269→    }
270→
271→    /**
272→     * Get config for route by strategy type, converted to strongly-typed object.
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>