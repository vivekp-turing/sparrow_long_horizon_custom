248→     * - "route" → uses "global" for global counting
249→     */
250→    private String buildRateLimitKey(String routeId, String clientId, RateLimitConfig config) {
251→        StringBuilder key = new StringBuilder(config.keyPrefix);
252→
253→        // Include strategyId in key for precise management
254→        if (config.strategyId != null && !config.strategyId.isEmpty()) {
255→            key.append(config.strategyId).append(":");
256→        }
257→
258→        // For global strategies, use simplified key to ensure consistent counting across all routes
259→        // "combined" with global scope would create different keys per route, breaking the limit
260→        boolean isGlobalStrategy = routeId == null || routeId.isEmpty() || "global".equalsIgnoreCase(routeId);
261→
262→        switch (config.keyType) {
263→            case RateLimitConstants.KEY_TYPE_ROUTE:
264→                if (isGlobalStrategy) {
265→                    // Global strategy: use "global" as key for overall counting
266→                    key.append("global");
267→                } else {
268→                    key.append("route:").append(routeId);
269→                }
270→                break;
271→            case RateLimitConstants.KEY_TYPE_IP:
272→                key.append("ip:").append(clientId);
273→                break;
274→            case RateLimitConstants.KEY_TYPE_USER:
275→                // User-based key (requires authentication context)
276→                key.append("user:").append(clientId);
277→                break;
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>