365→    public List<StrategyTypeEntity> getStrategyTypesByCategory(String category) {
366→        return strategyTypeRepository.findByCategoryAndEnabledTrueOrderBySortOrder(category);
367→    }
368→
369→    /**
370→     * Get all categories.
371→     */
372→    public List<String> getAllCategories() {
373→        return strategyTypeRepository.findAllCategories();
374→    }
375→
376→    /**
377→     * Get full config schema for a strategy type (includes subSchemas for AUTH).
378→     */
379→    public Map<String, Object> getFullConfigSchema(String typeCode) {
380→        StrategyTypeEntity entity = getStrategyType(typeCode);
381→        if (entity == null) {
382→            return null;
383→        }
384→
385→        Map<String, Object> schema = parseConfigSchema(entity.getConfigSchema());
386→        if (schema == null) {
387→            return null;
388→        }
389→
390→        // For AUTH type, add subSchemas
391→        if ("AUTH".equals(typeCode) && Boolean.TRUE.equals(schema.get("hasSubSchemas"))) {
392→            schema.put("subSchemas", AUTH_SUB_SCHEMAS);
393→            schema.remove("hasSubSchemas");
394→        }
395→
396→        // For REQUEST_TRANSFORM type, add subSchemas
397→        if ("REQUEST_TRANSFORM".equals(typeCode) && Boolean.TRUE.equals(schema.get("hasSubSchemas"))) {
398→            schema.put("subSchemas", REQUEST_TRANSFORM_SUB_SCHEMAS);
399→            schema.remove("hasSubSchemas");
400→        }
401→
402→        // For RESPONSE_TRANSFORM type, add subSchemas
403→        if ("RESPONSE_TRANSFORM".equals(typeCode) && Boolean.TRUE.equals(schema.get("hasSubSchemas"))) {
404→            schema.put("subSchemas", RESPONSE_TRANSFORM_SUB_SCHEMAS);
405→            schema.remove("hasSubSchemas");
406→        }
407→
408→        return schema;
409→    }
410→
411→    /**
412→     * Convert entity to DTO with parsed configSchema.
413→     */
414→    public Map<String, Object> toDto(StrategyTypeEntity entity) {
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>