28→
29→    /**
30→     * Find traces by instanceId and trace ID containing (fuzzy search)
31→     */
32→    @Query("SELECT t FROM RequestTrace t WHERE t.instanceId = :instanceId AND LOWER(t.traceId) LIKE LOWER(CONCAT('%', :traceId, '%')) ORDER BY t.traceTime DESC")
33→    List<RequestTrace> findByInstanceIdAndTraceIdContaining(String instanceId, String traceId, Pageable pageable);
34→
35→    /**
36→     * Find all traces by instanceId
37→     */
38→    List<RequestTrace> findByInstanceId(String instanceId);
39→
40→    /**
41→     * Find traces by route ID
42→     */
43→    List<RequestTrace> findByRouteId(String routeId);
44→
45→    /**
46→     * Find traces by instanceId and routeId
47→     */
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>