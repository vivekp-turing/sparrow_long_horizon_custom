 960→        <Col span={colSpan} key={field.name}>
 961→          <Form.Item
 962→            name={[parentPath, field.name]}
 963→            label={label}
 964→            initialValue={field.default}
 965→          >
 966→            <Select style={{ width: '100%' }}>
 967→              {field.options?.map((opt) => (
 968→                <Select.Option key={opt.value} value={opt.value}>
 969→                  {opt.label}
 970→                </Select.Option>
 971→              ))}
 972→            </Select>
 973→          </Form.Item>
 974→        </Col>
 975→      );
 976→
 977→    case 'switch':
 978→      return (
 979→        <Col span={colSpan} key={field.name}>
 980→          <Form.Item
 981→            name={[parentPath, field.name]}
 982→            label={label}
 983→            valuePropName="checked"
 984→            initialValue={field.default ?? false}
 985→          >
 986→            <Switch />
 987→          </Form.Item>
 988→        </Col>
 989→      );
 990→
 991→    default:
 992→      return (
 993→        <Col span={colSpan} key={field.name}>
 994→          <Form.Item
 995→            name={[parentPath, field.name]}
 996→            label={label}
 997→            initialValue={field.default}
 998→          >
 999→            <Input placeholder={field.placeholder} />
1000→          </Form.Item>
1001→        </Col>
1002→      );
1003→  }
1004→}
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>