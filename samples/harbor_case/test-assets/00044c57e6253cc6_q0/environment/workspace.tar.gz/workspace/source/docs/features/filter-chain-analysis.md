290→    }
291→  ],
292→  "slowestFiltersBySelfTime": [
293→    {
294→      "filterName": "LoadBalancerFilter",
295→      "avgSelfTimeMs": "45.200"
296→    }
297→  ],
298→  "slowestFiltersByTotalTime": [
299→    {
300→      "filterName": "FilterChainTracking",
301→      "avgDurationMs": "430.977"
302→    }
303→  ]
304→}
305→```
306→
307→### Get Slowest Filters Ranking
308→
309→```bash
310→curl http://localhost:8080/internal/filter-chain/slowest-filters?limit=10
311→```
312→
313→Sort by **selfTime** average, accurately identify filters that need optimization.
314→
315→---
316→
317→## Performance Optimizations
318→
319→Implementation uses multiple optimizations:
320→
321→| Optimization | Description |
322→|--------------|-------------|
323→| **ConcurrentLinkedDeque** | High-concurrency queue for storing records |
324→| **Atomic Counters** | Atomic counters reduce lock contention |
325→| **Sliding Window** | Sliding window percentile calculation, avoiding full sorting |
326→| **Rolling Window** | Keep up to 1000 records, automatically evict old records |
327→
328→---
329→
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>