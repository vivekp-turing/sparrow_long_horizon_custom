270→     * Build client source topology.
271→     */
272→    private void buildClientTopology(String instanceId, int minutesAgo,
273→                                      TopologyGraph graph, TopologyNode gatewayNode) {
274→        try {
275→            // Get client IP distribution - use local time to match database storage
276→            LocalDateTime since = LocalDateTime.now().minusMinutes(minutesAgo);
277→
278→            log.info("Building client topology for instanceId={}, querying traces since {} ({} minutes ago)",
279→                    instanceId, since, minutesAgo);
280→
281→            String sql = "SELECT client_ip, COUNT(*) as request_count, " +
282→                    "SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) as error_count, " +
283→                    "AVG(latency_ms) as avg_latency " +
284→                    "FROM request_trace " +
285→                    "WHERE instance_id = ? AND trace_time >= ? " +
286→                    "GROUP BY client_ip ORDER BY request_count DESC LIMIT 20";
287→
288→            List<Map<String, Object>> clientStats = jdbcTemplate.queryForList(sql, instanceId, since);
289→
290→            log.info("Found {} distinct client IPs for instanceId={}", clientStats.size(), instanceId);
291→
292→            for (Map<String, Object> stat : clientStats) {
293→                String clientIp = (String) stat.get("client_ip");
294→                long requestCount = getLong(stat, "request_count");
295→                long errorCount = getLong(stat, "error_count");
296→                double avgLatency = getDouble(stat, "avg_latency");
297→
298→                // Create client node
299→                TopologyNode clientNode = new TopologyNode();
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>