 60→        return this.configService;
 61→    }
 62→
 63→    /**
 64→     * Create Nacos NamingService bean.
 65→     */
 66→    @Bean
 67→    public NamingService nacosNamingService() throws Exception {
 68→        String actualServerAddr = serverAddr != null ? serverAddr : "127.0.0.1:8848";
 69→        Properties props = new Properties();
 70→        props.setProperty("serverAddr", actualServerAddr);
 71→
 72→        // namespace is REQUIRED - gateway instance must have its own namespace for service discovery isolation
 73→        if (namespace == null || namespace.isEmpty()) {
 74→            throw new IllegalStateException("Nacos namespace is REQUIRED for gateway instance. " +
 75→                    "Please set NACOS_NAMESPACE environment variable or spring.cloud.nacos.namespace property. " +
 76→                    "Gateway cannot start without namespace isolation.");
 77→        }
 78→        props.setProperty("namespace", namespace);
 79→
 80→        log.info("Initializing Nacos NamingService with server: {} namespace: {}", actualServerAddr, namespace);
 81→
 82→        try {
 83→            this.namingService = NacosFactory.createNamingService(props);
 84→            log.info("Nacos NamingService initialized successfully");
 85→            return this.namingService;
 86→        } catch (Exception e) {
 87→            log.error("Failed to create Nacos NamingService. ServerAddr: {}, Namespace: {}. Error: {}",
 88→                    actualServerAddr, namespace, e.getMessage(), e);
 89→            throw e;
 90→        }
 91→    }
 92→
 93→    /**
 94→     * Create NacosConfigService wrapper bean.
 95→     */
 96→    @Bean
 97→    public NacosConfigService nacosConfigServiceWrapper(ConfigService nacosConfigService) {
 98→        return new NacosConfigService(nacosConfigService);
 99→    }
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>