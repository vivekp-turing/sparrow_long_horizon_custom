215→     * Examples: "100ms", "1s", "60s", "2min", "1h"
216→     */
217→    private static String formatWindowSize(long windowMs) {
218→        if (windowMs < 1000) {
219→            return windowMs + "ms";
220→        } else if (windowMs < 60000) {
221→            long seconds = windowMs / 1000;
222→            return seconds + "s";
223→        } else if (windowMs < 3600000) {
224→            long minutes = windowMs / 60000;
225→            return minutes + "min";
226→        } else {
227→            long hours = windowMs / 3600000;
228→            return hours + "h";
229→        }
230→    }
231→
232→    /**
233→     * Write 503 Service Unavailable response (circuit breaker open).
234→     * <p>
235→     * Response format includes httpStatus for clarity.
236→     *
237→     * @param response ServerHttpResponse
238→     * @param routeId  Route ID that triggered circuit breaker
239→     */
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>