120→
121→                    log.debug("Selected instance: {}:{} (weight={}) for service: {}, namespace: {}, group: {}",
122→                            instance.getHost(), instance.getPort(), instance.getMetadata().get("weight"),
123→                            serviceName, namespace, group);
124→
125→                    // Continue with the modified URI (skip native lb filter)
126→                    return chain.filter(exchange);
127→                })
128→                .onErrorResume(e -> {
129→                    log.error("Error discovering instances for service: {}, namespace: {}, group: {}",
130→                            serviceName, namespace, group, e);
131→                    exchange.getResponse().setStatusCode(HttpStatus.SERVICE_UNAVAILABLE);
132→                    return exchange.getResponse().setComplete();
133→                });
134→    }
135→
136→    /**
137→     * Choose an instance using weighted round-robin.
138→     * Filters out disabled and unhealthy instances.
139→     */
140→    private Mono<org.springframework.cloud.client.ServiceInstance> chooseInstance(String serviceName, String namespace, String group) {
141→        try {
142→            List<ServiceInstance> instances = nacosDiscoveryService.getHealthyInstances(serviceName, namespace, group);
143→
144→            if (instances == null || instances.isEmpty()) {
145→                log.warn("No healthy instances found for service: {}, namespace: {}, group: {}",
146→                        serviceName, namespace, group);
147→                return Mono.empty();
148→            }
149→
150→            // Filter out disabled instances (user set enabled=false in Nacos)
151→            List<ServiceInstance> enabledInstances = instances.stream()
152→                    .filter(ServiceInstance::isEnabled)
153→                    .collect(Collectors.toList());
154→
155→            if (enabledInstances.isEmpty()) {
156→                log.warn("All instances are DISABLED for service: {}, namespace: {}, group: {}",
157→                        serviceName, namespace, group);
158→                return Mono.empty();
159→            }
160→
161→            // Select instance using weighted round-robin
162→            ServiceInstance selected = selectByWeightedRoundRobin(serviceName, enabledInstances);
163→
164→            // Convert to Spring Cloud ServiceInstance
165→            org.springframework.cloud.client.ServiceInstance springInstance = new SimpleServiceInstance(selected);
166→            return Mono.just(springInstance);
167→        } catch (Exception e) {
168→            log.error("Error getting instances for service: {}, namespace: {}, group: {}",
169→                    serviceName, namespace, group, e);
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>