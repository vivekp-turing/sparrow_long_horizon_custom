100→    }
101→
102→    /**
103→     * Get strategies for a route.
104→     */
105→    @GetMapping("/route/{routeId}")
106→    public ResponseEntity<Map<String, Object>> getStrategiesForRoute(@PathVariable String routeId) {
107→        List<StrategyDefinition> strategies = strategyService.getStrategiesForRoute(routeId);
108→        return ok(strategies);
109→    }
110→
111→    /**
112→     * Create a new strategy.
113→     * @param instanceId Optional instance ID for configuration isolation
114→     */
115→    @PostMapping
116→    public ResponseEntity<Map<String, Object>> createStrategy(
117→            @RequestBody StrategyDefinition strategy,
118→            @RequestParam(required = false) String instanceId,
119→            HttpServletRequest request) {
120→        try {
121→            log.info("Creating strategy: {} for instance: {}", strategy.getStrategyName(), instanceId);
122→            StrategyEntity entity = strategyService.createStrategy(strategy, instanceId);
123→
124→            // Record audit log - CREATE
125→            String newValue = objectMapper.writeValueAsString(strategy);
126→            auditLogService.recordAuditLog(getOperator(), "CREATE", "STRATEGY", entity.getStrategyId(),
127→                    strategy.getStrategyName(), null, newValue, getIpAddress(request));
128→
129→            return ok(strategy, "Strategy created successfully");
130→        } catch (IllegalArgumentException e) {
131→            log.warn("Failed to create strategy: {}", e.getMessage());
132→            return badRequest(e.getMessage());
133→        } catch (Exception e) {
134→            log.error("Failed to create strategy", e);
135→            return error("Failed to create strategy: " + e.getMessage());
136→        }
137→    }
138→
139→    /**
140→     * Update a strategy.
141→     */
142→    @PutMapping("/{id}")
143→    public ResponseEntity<Map<String, Object>> updateStrategy(
144→            @PathVariable String id,
145→            @RequestBody StrategyDefinition strategy,
146→            HttpServletRequest request) {
147→        try {
148→            log.info("Updating strategy: {}", id);
149→
150→            // Get old value before update
151→            StrategyEntity oldEntity = strategyService.getStrategyEntity(id);
152→            String oldValue = oldEntity != null ? oldEntity.getMetadata() : null;
153→
154→            StrategyEntity entity = strategyService.updateStrategy(id, strategy);
155→
156→            // Record audit log - UPDATE
157→            String newValue = objectMapper.writeValueAsString(strategy);
158→            auditLogService.recordAuditLog(getOperator(), "UPDATE", "STRATEGY", id,
159→                    strategy.getStrategyName(), oldValue, newValue, getIpAddress(request));
160→
161→            return ok(strategy, "Strategy updated successfully");
162→        } catch (IllegalArgumentException e) {
163→            log.warn("Failed to update strategy: {}", e.getMessage());
164→            return notFound(e.getMessage());
165→        } catch (Exception e) {
166→            log.error("Failed to update strategy", e);
167→            return error("Failed to update strategy: " + e.getMessage());
168→        }
169→    }
170→
171→    /**
172→     * Delete a strategy.
173→     */
174→    @DeleteMapping("/{id}")
175→    public ResponseEntity<Map<String, Object>> deleteStrategy(@PathVariable String id, HttpServletRequest request) {
176→        try {
177→            log.info("Deleting strategy: {}", id);
178→
179→            // Get old value before delete
180→            StrategyEntity oldEntity = strategyService.getStrategyEntity(id);
181→            String oldValue = oldEntity != null ? oldEntity.getMetadata() : null;
182→            String targetName = oldEntity != null ? oldEntity.getStrategyName() : id;
183→
184→            strategyService.deleteStrategy(id);
185→
186→            // Record audit log - DELETE
187→            auditLogService.recordAuditLog(getOperator(), "DELETE", "STRATEGY", id,
188→                    targetName, oldValue, null, getIpAddress(request));
189→
190→            return ok(null, "Strategy deleted successfully");
191→        } catch (IllegalArgumentException e) {
192→            log.warn("Failed to delete strategy: {}", e.getMessage());
193→            return notFound(e.getMessage());
194→        } catch (Exception e) {
195→            log.error("Failed to delete strategy", e);
196→            return error("Failed to delete strategy: " + e.getMessage());
197→        }
198→    }
199→
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>