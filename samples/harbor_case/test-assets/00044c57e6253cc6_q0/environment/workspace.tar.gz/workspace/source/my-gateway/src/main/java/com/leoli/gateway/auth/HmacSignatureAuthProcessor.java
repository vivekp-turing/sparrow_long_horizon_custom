package com.leoli.gateway.auth;

import com.leoli.gateway.constants.AuthConstants;
import com.leoli.gateway.enums.AuthType;
import com.leoli.gateway.model.AuthConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * HMAC Signature Authentication Processor.
 * Validates requests using HMAC signature (similar to AWS Signature V4).
 * <p>
 * Features:
 * - Request signing with HMAC-SHA256
 * - Timestamp validation to prevent replay attacks
 * - Content-MD5 validation for request body integrity
 * - Custom header support
 * - Multiple access key support
 *
 * @author leoli
 */
@Slf4j
@Component
public class HmacSignatureAuthProcessor extends AbstractAuthProcessor {

    // Standard headers for signature
    private static final String X_ACCESS_KEY = "X-Access-Key";
    private static final String X_SIGNATURE = "X-Signature";
    private static final String X_TIMESTAMP = "X-Timestamp";
    private static final String X_NONCE = "X-Nonce";
    private static final String X_CONTENT_MD5 = "X-Content-MD5";

    // Default clock skew tolerance in minutes
    private static final int DEFAULT_CLOCK_SKEW_MINUTES = 5;

    // In-memory nonce cache for replay attack prevention
    private final Map<String, Long> nonceCache = new ConcurrentHashMap<>();
    private static final long NONCE_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes

    @Override
    public AuthType getAuthType() {
        return AuthType.HMAC;
    }

    @Override
    public Mono<Void> process(ServerWebExchange exchange, AuthConfig config) {
        if (!isValidConfig(config)) {
