301→    /**
302→     * Get certificate statistics
303→     */
304→    public Map<String, Object> getCertificateStats() {
305→        Map<String, Object> stats = new HashMap<>();
306→        stats.put("total", sslCertificateRepository.count());
307→        stats.put("valid", sslCertificateRepository.countByStatus("VALID"));
308→        stats.put("expiringSoon", sslCertificateRepository.countByStatus("EXPIRING_SOON"));
309→        stats.put("expired", sslCertificateRepository.countByStatus("EXPIRED"));
310→        stats.put("expiringList", getExpiringCertificates(30));
311→        return stats;
312→    }
313→
314→    /**
315→     * Parse PEM certificate
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>