1240→              </>
1241→            )}
1242→          </Space>
1243→        }
1244→        placement="right"
1245→        width={1000}
1246→        onClose={() => {
1247→          setJaegerDetailDrawerVisible(false);
1248→          setSelectedJaegerTrace(null);
1249→        }}
1250→        open={jaegerDetailDrawerVisible}
1251→        styles={{ body: { padding: 16 } }}
1252→      >
1253→        {selectedJaegerTrace && (
1254→          <div>
1255→            {/* Trace Summary */}
1256→            <Card size="small" style={{ marginBottom: 16 }}>
1257→              <Row gutter={16}>
1258→                <Col span={6}>
1259→                  <Statistic title={t('trace.trace_id')} valueStyle={{ fontSize: 12 }}
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>