260→    }
261→
262→    /**
263→     * Update global QPS snapshots from Redis.
264→     * Uses SCAN command (non-blocking) instead of KEYS (blocking).
265→     */
266→    private void updateGlobalQpsSnapshots() {
267→        int nodeCount = cachedNodeCount.get();
268→
269→        for (String routeId : shadowQuotas.keySet()) {
270→            try {
271→                long totalQps = 0;
272→
273→                // Use SCAN (non-blocking) instead of KEYS (blocking)
274→                String pattern = "rate_limit:*:" + routeId + "*";
275→                ScanOptions scanOptions = ScanOptions.scanOptions()
276→                    .match(pattern)
277→                    .count(100)
278→                    .build();
279→
280→                try (Cursor<String> cursor = redisTemplate.scan(scanOptions)) {
281→                    while (cursor.hasNext()) {
282→                        String key = cursor.next();
283→                        try {
284→                            Long count = redisTemplate.opsForZSet().zCard(key);
285→                            if (count != null) {
286→                                totalQps += count;
287→                            }
288→                        } catch (Exception e) {
289→                            log.trace("Skipping key {}: {}", key, e.getMessage());
290→                        }
291→                    }
292→                }
293→
294→                // Also try the direct route key pattern
295→                String directKey = "rate_limit:route:" + routeId;
296→                try {
297→                    Long directCount = redisTemplate.opsForZSet().zCard(directKey);
298→                    if (directCount != null && directCount > 0) {
299→                        totalQps = Math.max(totalQps, directCount);
300→                    }
301→                } catch (Exception e) {
302→                    log.trace("No direct key for route {}: {}", routeId, e.getMessage());
303→                }
304→
305→                if (totalQps > 0) {
306→                    globalQpsSnapshots.computeIfAbsent(routeId, k -> new AtomicLong(0))
307→                            .set(totalQps);
308→
309→                    // Calculate shadow quota: globalQPS / nodeCount
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>