920→        } catch (Exception e) {
921→            return 0;
922→        }
923→    }
924→
925→    private Long extractLong(Object obj) {
926→        if (obj == null) return null;
927→        if (obj instanceof Number) {
928→            return ((Number) obj).longValue();
929→        }
930→        try {
931→            return Long.parseLong(obj.toString());
932→        } catch (NumberFormatException e) {
933→            return null;
934→        }
935→    }
936→
937→    private Integer extractInteger(Object obj) {
938→        if (obj == null) return null;
939→        if (obj instanceof Number) {
940→            return ((Number) obj).intValue();
941→        }
942→        try {
943→            return Integer.parseInt(obj.toString());
944→        } catch (NumberFormatException e) {
945→            return null;
946→        }
947→    }
948→
949→    private double parseDoubleStr(String str) {
950→        if (str == null) return 0;
951→        try {
952→            return Double.parseDouble(str);
953→        } catch (NumberFormatException e) {
954→            return 0;
955→        }
956→    }
957→
958→    // ============== Diagnostic History Methods ==============
959→
960→    /**
961→     * Save diagnostic result to history table.
962→     */
963→    private void saveDiagnosticHistory(DiagnosticReport report, String diagnosticType, String instanceId) {
964→        try {
965→            DiagnosticHistoryEntity history = new DiagnosticHistoryEntity();
966→            history.setInstanceId(instanceId);
967→            history.setDiagnosticType(diagnosticType);
968→            history.setOverallScore(report.getOverallScore());
969→            history.setStatus(report.getOverallScore() >= 80 ? "HEALTHY" :
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>