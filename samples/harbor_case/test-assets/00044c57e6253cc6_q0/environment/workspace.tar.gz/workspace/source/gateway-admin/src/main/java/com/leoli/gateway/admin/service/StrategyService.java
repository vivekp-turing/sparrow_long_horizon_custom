750→     * Convert entity to definition.
751→     */
752→    private StrategyDefinition toDefinition(StrategyEntity entity) {
753→        if (entity.getMetadata() != null && !entity.getMetadata().isEmpty()) {
754→            try {
755→                StrategyDefinition strategy = objectMapper.readValue(entity.getMetadata(), StrategyDefinition.class);
756→                if (strategy != null) {
757→                    // Ensure fields are synced
758→                    strategy.setStrategyId(entity.getStrategyId());
759→                    strategy.setEnabled(entity.getEnabled());
760→                    return strategy;
761→                }
762→            } catch (Exception e) {
763→                log.warn("Failed to deserialize strategy config", e);
764→            }
765→        }
766→
767→        // Fallback
768→        StrategyDefinition strategy = new StrategyDefinition();
769→        strategy.setStrategyId(entity.getStrategyId());
770→        strategy.setStrategyName(entity.getStrategyName());
771→        strategy.setStrategyType(entity.getStrategyType());
772→        strategy.setScope(entity.getScope());
773→        strategy.setRouteId(entity.getRouteId());
774→        strategy.setPriority(entity.getPriority() != null ? entity.getPriority() : 100);
775→        strategy.setEnabled(entity.getEnabled());
776→        strategy.setDescription(entity.getDescription());
777→        return strategy;
778→    }
779→
780→    /**
781→     * Convert definition to entity.
782→     */
783→    private StrategyEntity toEntity(StrategyDefinition strategy) {
784→        StrategyEntity entity = new StrategyEntity();
785→        entity.setStrategyId(strategy.getStrategyId());
786→        entity.setStrategyName(strategy.getStrategyName());
787→        entity.setStrategyType(strategy.getStrategyType());
788→        entity.setScope(strategy.getScope());
789→        entity.setRouteId(strategy.getRouteId());
790→        entity.setPriority(strategy.getPriority());
791→        entity.setEnabled(strategy.isEnabled());
792→        entity.setDescription(strategy.getDescription());
793→
794→        try {
795→            String configJson = objectMapper.writeValueAsString(strategy);
796→            entity.setMetadata(configJson);
797→        } catch (Exception e) {
798→            log.warn("Failed to serialize strategy config", e);
799→        }
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>