 80→        }
 81→
 82→        // Burst capacity validation (int type, always has value)
 83→        int burstCapacity = config.getBurstCapacity();
 84→        if (burstCapacity < 0) {
 85→            errors.add("burstCapacity cannot be negative, got: " + burstCapacity);
 86→        }
 87→        // burstCapacity must be >= qps for meaningful burst handling
 88→        if (burstCapacity < qps) {
 89→            errors.add("burstCapacity (" + burstCapacity + ") must be >= qps (" + qps + 
 90→                    "). Burst capacity should allow handling traffic spikes beyond steady rate.");
 91→        }
 92→
 93→        // Time unit validation
 94→        if (config.getTimeUnit() != null) {
 95→            String timeUnit = config.getTimeUnit().toLowerCase();
 96→            if (!List.of("second", "minute", "hour").contains(timeUnit)) {
 97→                errors.add("Invalid timeUnit: " + config.getTimeUnit() + ", must be one of: second, minute, hour");
 98→            }
 99→        }
100→
101→        // Key resolver validation
102→        if (config.getKeyResolver() != null) {
103→            String keyResolver = config.getKeyResolver().toLowerCase();
104→            if (!List.of("ip", "user", "header", "global").contains(keyResolver)) {
105→                errors.add("Invalid keyResolver: " + config.getKeyResolver() + ", must be one of: ip, user, header, global");
106→            }
107→        }
108→
109→        // Key type validation
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>