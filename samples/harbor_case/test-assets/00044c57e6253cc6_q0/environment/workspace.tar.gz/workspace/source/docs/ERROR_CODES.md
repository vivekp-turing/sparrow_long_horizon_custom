## Usage Examples

### Frontend Error Handling

```javascript
async function handleResponse(response) {
    const data = await response.json();
    
    // Check httpStatus first
    if (data.httpStatus >= 400) {
        // Use code for programmatic handling
        switch (data.code) {
            case 42901:  // Rate limit
                console.log(`Rate limited, retry after ${data.retryAfterSec} seconds`);
                break;
            case 40101:  // Unauthorized
                console.log('Please login again');
                break;
            default:
                console.log(data.message);
        }
    }
}
```

### Java Error Handling

```java
// Using ErrorCode enum
ErrorCode error = ErrorCode.fromCode(response.getCode());
