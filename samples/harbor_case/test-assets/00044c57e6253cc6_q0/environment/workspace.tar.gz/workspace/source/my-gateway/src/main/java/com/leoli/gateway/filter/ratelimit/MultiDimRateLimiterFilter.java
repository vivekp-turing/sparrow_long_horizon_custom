package com.leoli.gateway.filter.ratelimit;

import com.leoli.gateway.constants.FilterOrderConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.leoli.gateway.limiter.RateLimitResult;
import com.leoli.gateway.limiter.RedisHealthChecker;
import com.leoli.gateway.limiter.DistributedRateLimiter;
import com.leoli.gateway.limiter.ShadowQuotaManager;
import com.leoli.gateway.manager.StrategyManager;
import com.leoli.gateway.model.MultiDimRateLimiterConfig;
import com.leoli.gateway.model.StrategyDefinition;
import com.leoli.gateway.util.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Multi-Dimensional Rate Limiter Filter.
 * <p>
 * Supports hierarchical rate limiting with independent counting per dimension:
 * - Global: Overall quota for the entire route
 * - Tenant: Per-tenant quota (extracted from API Key metadata or JWT claims)
 * - User: Per-user quota (extracted from JWT subject or header)
 * - IP: Per-client-IP quota
 * <p>
 * Each dimension is counted independently. Any dimension exceeding its limit
 * will result in 429 response.
 *
 * @author leoli
 */
@Component
@Slf4j
public class MultiDimRateLimiterFilter implements GlobalFilter, Ordered {

    @Autowired
    private StrategyManager strategyManager;

    @Autowired(required = false)
    private RedisHealthChecker redisHealthChecker;

    @Autowired(required = false)
    private DistributedRateLimiter distributedRateLimiter;

    @Autowired
    private ShadowQuotaManager shadowQuotaManager;

    @Autowired
    private ObjectMapper objectMapper;  // Use injected ObjectMapper

    @Value("${gateway.rate-limiter.redis.enabled:true}")
    private boolean redisLimitEnabled;

    @Value("${gateway.rate-limiter.shadow-quota.enabled:true}")
    private boolean shadowQuotaEnabled;

    /**
     * Local rate limiter cache: key -> RateLimiterWindow.
     */
    private final Cache<String, com.leoli.gateway.util.RateLimiterWindow> rateLimiterCache = Caffeine.newBuilder()
            .maximumSize(50000)
            .expireAfterWrite(1, TimeUnit.HOURS)
            .build();

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String routeId = RouteUtils.getRouteId(exchange);

        // Get config from strategy manager
        ConfigWrapper config = getConfig(routeId);

        if (!config.enabled || !config.multiDimConfig.isAnyDimensionEnabled()) {
            return chain.filter(exchange);
        }

        // Extract dimension identifiers
        String tenantId = extractTenantId(exchange, config.multiDimConfig);
        String userId = extractUserId(exchange, config.multiDimConfig);
        String clientIp = IpAddressExtractor.extractClientIp(exchange);

        if (log.isDebugEnabled()) {
            log.debug("Multi-dim rate limiter - routeId: {}, tenantId: {}, userId: {}, ip: {}",
                    routeId, tenantId, userId, clientIp);
        }

        // Build dimension keys
