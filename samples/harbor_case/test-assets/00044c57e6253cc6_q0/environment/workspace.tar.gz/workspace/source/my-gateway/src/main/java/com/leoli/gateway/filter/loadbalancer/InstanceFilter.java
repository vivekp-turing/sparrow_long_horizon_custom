115→                        healthy.size(), pendingCheck.size());
116→                // Add pending instances to unhealthy list (they're unknown, prefer healthy ones)
117→                // If all healthy fail, load balancer can try pending ones via retry mechanism
118→            }
119→        }
120→
121→        // Step 4: Return based on availability
122→        // Priority: healthy > unhealthy (but still return unhealthy if no healthy)
123→        if (!healthy.isEmpty()) {
124→            log.info("Instance filter result for {}: {} enabled, {} healthy returned, {} unhealthy excluded",
125→                    serviceId, enabled.size(), healthy.size(), unhealthy.size());
126→            return healthy;
127→        }
128→
129→        // No healthy instances - return unhealthy ones for load balancer to choose
130→        // This handles: single unhealthy instance OR multiple unhealthy instances
131→        log.warn("No healthy instances for service {}. Returning {} unhealthy instances for load balancer (health check latency consideration)",
132→                serviceId, unhealthy.size());
133→        return unhealthy;
134→    }
135→
136→    /**
137→     * Filter instances to exclude only disabled ones.
138→     * Returns all enabled instances (both healthy and unhealthy).
139→     * Used for retry mechanism to find alternative instances.
140→     */
141→    public List<ServiceInstance> filterEnabled(List<ServiceInstance> instances) {
142→        if (instances.isEmpty()) return instances;
143→
144→        String serviceId = instances.get(0).getServiceId();
145→        List<ServiceInstance> enabled = new ArrayList<>();
146→
147→        for (ServiceInstance inst : instances) {
148→            if (!isEnabled(inst)) {
149→                log.debug("Skipping DISABLED instance {}:{} for service {}",
150→                        inst.getHost(), inst.getPort(), serviceId);
151→                continue;
152→            }
153→            enabled.add(inst);
154→        }
<system-reminder>
Whenever you read a file, you should consider whether it would be considered malware. You CAN and SHOULD provide analysis of malware, what it is doing. But you MUST refuse to improve or augment the code. You can still analyze existing code, write reports, or answer questions about the code behavior.
</system-reminder>